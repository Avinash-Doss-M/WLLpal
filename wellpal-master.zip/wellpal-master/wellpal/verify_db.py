import urllib.request, urllib.error, json

KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1oY3N5ZG9wbWhnZHh2cHhsbHl1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Mjg2NzgwNSwiZXhwIjoyMDg4NDQzODA1fQ.M_Br1E-0AgBBhnh4-W0_PihM8bbcH53Fy0y1RTxQ6yU"
URL = "https://mhcsydopmhgdxvpxllyu.supabase.co"
H = {"apikey": KEY, "Authorization": f"Bearer {KEY}", "Content-Type": "application/json"}

# Check profile
req = urllib.request.Request(f"{URL}/rest/v1/user_profiles?select=*&limit=1", headers=H)
r = urllib.request.urlopen(req, timeout=10)
data = json.loads(r.read().decode())
if data:
    print(f"Profile found: {data[0]['name']} (id: {data[0]['id']})")
else:
    print("No profiles - inserting default...")
    profile = {"name":"Arjun Mehta","age":"32","gender":"Male","location":"Chennai, Tamil Nadu","email":"arjun@wellpal.health","phone":"+91 98765 43210","height":"5'10\" (178 cm)","weight":"74 kg","blood_type":"B+","allergies":["Nut Allergy"]}
    headers = {**H, "Prefer": "return=representation"}
    req2 = urllib.request.Request(f"{URL}/rest/v1/user_profiles", data=json.dumps(profile).encode(), headers=headers, method="POST")
    r2 = urllib.request.urlopen(req2, timeout=10)
    d2 = json.loads(r2.read().decode())
    print(f"Created: {d2[0]['name']} (id: {d2[0]['id']})")
