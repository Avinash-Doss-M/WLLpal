import urllib.request, json

BASE = "http://localhost:3000"

def api(method, path, body=None):
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(f"{BASE}{path}", data=data, headers={"Content-Type":"application/json"}, method=method)
    r = urllib.request.urlopen(req, timeout=10)
    return json.loads(r.read().decode())

print("=== Testing Wellpal API ===\n")

# 1. Get profile
print("1. GET /api/profile")
profile = api("GET", "/api/profile")
print(f"   Name: {profile.get('name')}, ID: {profile.get('id')}")
pid = profile.get("id")

# 2. Create a chat session
print("\n2. POST /api/sessions")
session = api("POST", "/api/sessions", {"title": "Test: Drug interaction check", "profile_id": pid})
print(f"   Session: {session.get('id')}, Title: {session.get('title')}")
sid = session.get("id")

# 3. Save messages
print("\n3. POST /api/messages (user)")
msg1 = api("POST", "/api/messages", {"session_id": sid, "role": "user", "content": "Can I take Ibuprofen with BP medication?"})
print(f"   Saved: {msg1.get('id')}")

print("   POST /api/messages (model)")
msg2 = api("POST", "/api/messages", {"session_id": sid, "role": "model", "content": "NSAIDs like Ibuprofen can interact with blood pressure medications. Please consult your doctor."})
print(f"   Saved: {msg2.get('id')}")

# 4. Get messages
print("\n4. GET /api/messages")
msgs = api("GET", f"/api/messages?session_id={sid}")
print(f"   Messages: {len(msgs)}")
for m in msgs:
    print(f"   [{m['role']}] {m['content'][:50]}...")

# 5. Get sessions
print("\n5. GET /api/sessions")
sessions = api("GET", f"/api/sessions?profile_id={pid}")
print(f"   Sessions: {len(sessions)}")

# 6. Get chat history (with messages)
print("\n6. GET /api/chat-history")
history = api("GET", f"/api/chat-history?profile_id={pid}")
print(f"   Sessions with messages: {len(history)}")
for h in history:
    print(f"   '{h['title']}' — {len(h.get('messages',[]))} msgs")

# 7. Update profile
print("\n7. PATCH /api/profile")
updated = api("PATCH", f"/api/profile?id={pid}", {"name": "Arjun Mehta", "location": "Chennai, Tamil Nadu"})
print(f"   Updated: {updated.get('name')}")

print("\n=== ALL TESTS PASSED ===")
