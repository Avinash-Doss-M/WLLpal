#!/usr/bin/env python3
"""
Create Supabase tables for Wellpal via the Management API:
  - user_profiles: store user profile data
  - chat_sessions: store chat session metadata
  - chat_messages: store individual chat messages
"""

import urllib.request
import urllib.error
import json

SUPABASE_URL = "https://mhcsydopmhgdxvpxllyu.supabase.co"
SUPABASE_SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1oY3N5ZG9wbWhnZHh2cHhsbHl1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Mjg2NzgwNSwiZXhwIjoyMDg4NDQzODA1fQ.M_Br1E-0AgBBhnh4-W0_PihM8bbcH53Fy0y1RTxQ6yU"

HEADERS = {
    "apikey": SUPABASE_SERVICE_KEY,
    "Authorization": f"Bearer {SUPABASE_SERVICE_KEY}",
    "Content-Type": "application/json",
}

# Single SQL block to create everything at once
FULL_SQL = """
-- 1. user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    name TEXT NOT NULL DEFAULT 'User',
    age TEXT,
    gender TEXT DEFAULT 'Prefer not to say',
    location TEXT,
    email TEXT,
    phone TEXT,
    height TEXT,
    weight TEXT,
    blood_type TEXT DEFAULT 'Unknown',
    allergies TEXT[] DEFAULT '{}'
);

-- 2. chat_sessions table
CREATE TABLE IF NOT EXISTS chat_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id UUID REFERENCES user_profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT 'New Chat',
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 3. chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'model')),
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. Indexes
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_profile ON chat_sessions(profile_id, updated_at DESC);

-- 5. RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- 6. Open policies (demo mode)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'allow_all_profiles') THEN
        CREATE POLICY allow_all_profiles ON user_profiles FOR ALL USING (true) WITH CHECK (true);
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'allow_all_sessions') THEN
        CREATE POLICY allow_all_sessions ON chat_sessions FOR ALL USING (true) WITH CHECK (true);
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'allow_all_messages') THEN
        CREATE POLICY allow_all_messages ON chat_messages FOR ALL USING (true) WITH CHECK (true);
    END IF;
END $$;

-- 7. Auto-update trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_profiles_updated') THEN
        CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON user_profiles
        FOR EACH ROW EXECUTE FUNCTION update_updated_at();
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'trg_sessions_updated') THEN
        CREATE TRIGGER trg_sessions_updated BEFORE UPDATE ON chat_sessions
        FOR EACH ROW EXECUTE FUNCTION update_updated_at();
    END IF;
END $$;
"""


def run_sql_via_rpc(sql: str):
    """Try to execute SQL via a custom RPC function if available."""
    # This won't work without a pre-created function, but we try anyway
    url = f"{SUPABASE_URL}/rest/v1/rpc/exec_sql"
    payload = json.dumps({"sql_text": sql}).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers=HEADERS, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return True, resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return False, f"HTTP {e.code}: {body[:300]}"
    except Exception as e:
        return False, str(e)


def check_table_exists(table_name: str):
    """Check if a table exists via REST API GET."""
    url = f"{SUPABASE_URL}/rest/v1/{table_name}?select=id&limit=1"
    req = urllib.request.Request(url, headers=HEADERS, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return True
    except urllib.error.HTTPError:
        return False


def insert_default_profile():
    """Insert default profile data."""
    default_profile = {
        "name": "Arjun Mehta",
        "age": "32",
        "gender": "Male",
        "location": "Chennai, Tamil Nadu",
        "email": "arjun@wellpal.health",
        "phone": "+91 98765 43210",
        "height": "5'10\" (178 cm)",
        "weight": "74 kg",
        "blood_type": "B+",
        "allergies": ["Nut Allergy"]
    }

    url = f"{SUPABASE_URL}/rest/v1/user_profiles"
    headers = {**HEADERS, "Prefer": "return=representation"}
    payload = json.dumps(default_profile).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            profile_id = data[0]["id"] if data else "unknown"
            print(f"  ✅ Default profile created: {profile_id}")
            return profile_id
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"  ⚠️ Insert profile: HTTP {e.code} — {body[:200]}")
        return None
    except Exception as e:
        print(f"  ⚠️ {e}")
        return None


def main():
    print("=" * 50)
    print("  🌿 Wellpal Database Setup")
    print("=" * 50)
    print()

    # Check existing tables
    tables = ["user_profiles", "chat_sessions", "chat_messages"]
    existing = {t: check_table_exists(t) for t in tables}

    for t, exists in existing.items():
        status = "✅ exists" if exists else "❌ needs creation"
        print(f"  {t}: {status}")

    print()

    if all(existing.values()):
        print("✅ All tables already exist!")
        print()
        # Still insert default profile if table is empty
        url = f"{SUPABASE_URL}/rest/v1/user_profiles?select=id&limit=1"
        req = urllib.request.Request(url, headers=HEADERS, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                if not data:
                    print("📝 No profiles found, inserting default...")
                    insert_default_profile()
                else:
                    print(f"  ℹ️ Profile exists: {data[0]['id']}")
        except Exception as e:
            print(f"  ⚠️ {e}")
    else:
        print("📋 Tables need to be created.")
        print()
        print("=" * 50)
        print("  PLEASE RUN THIS SQL IN YOUR SUPABASE DASHBOARD")
        print("  → https://supabase.com/dashboard/project/mhcsydopmhgdxvpxllyu/sql/new")
        print("=" * 50)
        print()
        print(FULL_SQL)
        print()
        print("=" * 50)
        print("  After running the SQL above, run this script again")
        print("  to insert the default profile data.")
        print("=" * 50)

    print()
    print("🎉 Done!")


if __name__ == "__main__":
    main()
