import urllib.request, urllib.error, json

KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1oY3N5ZG9wbWhnZHh2cHhsbHl1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3Mjg2NzgwNSwiZXhwIjoyMDg4NDQzODA1fQ.M_Br1E-0AgBBhnh4-W0_PihM8bbcH53Fy0y1RTxQ6yU"
URL = "https://mhcsydopmhgdxvpxllyu.supabase.co"
H = {"apikey": KEY, "Authorization": f"Bearer {KEY}", "Content-Type": "application/json"}

for t in ["user_profiles", "chat_sessions", "chat_messages"]:
    req = urllib.request.Request(f"{URL}/rest/v1/{t}?select=id&limit=1", headers=H)
    try:
        r = urllib.request.urlopen(req, timeout=10)
        print(f"{t}: EXISTS ({r.read().decode()[:60]})")
    except urllib.error.HTTPError as e:
        print(f"{t}: HTTP {e.code} — {e.read().decode()[:100]}")
    except Exception as e:
        print(f"{t}: ERROR — {e}")
